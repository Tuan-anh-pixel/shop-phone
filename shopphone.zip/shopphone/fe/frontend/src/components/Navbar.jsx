import { Navbar, Nav, Container, Button, NavDropdown } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";

const AppNavbar = () => {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <Navbar bg="light" expand="lg" className="shadow-sm">
      <Container>
        <Navbar.Brand as={Link} to="/" className="fw-bold text-primary">
          📱 SmartPhone Shop
        </Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse>
          <Nav className="ms-auto align-items-center">

            <Nav.Link as={Link} to="/">Trang chủ</Nav.Link>

            {token && user?.role === "admin" && (
              <NavDropdown title="📊 Dashboard" id="admin-nav">
                <NavDropdown.Item as={Link} to="/products">Quản lý sản phẩm</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/categories">Quản lý danh mục</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/orders">Quản lý đơn hàng</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/users">Quản lý người dùng</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/store">Thông tin cửa hàng</NavDropdown.Item>
              </NavDropdown>
            )}

            {token ? (
              <>
                {user?.role !== "admin" && (
                  <Nav.Link as={Link} to="/my-orders">
                    Đơn hàng của tôi
                  </Nav.Link>
                )}
                <Button variant="outline-danger" onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right"></i> Đăng xuất
                </Button>
              </>
            ) : (
              <>
                <Nav.Link as={Link} to="/login">Đăng nhập</Nav.Link>
                <Nav.Link as={Link} to="/register">Đăng ký</Nav.Link>
              </>
            )}

          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;
