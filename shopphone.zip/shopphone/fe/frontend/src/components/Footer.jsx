import { useEffect, useState } from 'react';
import axios from '../api/axios';

const Footer = () => {
  const [store, setStore] = useState(null);

  useEffect(() => {
    const fetchStore = async () => {
      try {
        const res = await axios.get('/store');
        setStore(res.data.store);
      } catch (err) {
        console.log('Không thể lấy thông tin cửa hàng');
      }
    };
    fetchStore();
  }, []);

  return (
    <footer className="bg-dark text-light pt-5 pb-4">
      <div className="container">
        <div className="row">
          {/* Cột 1: Thông tin cửa hàng */}
          <div className="col-md-4 mb-3">
            <h5 className="fw-bold text-uppercase">
              {store?.name || 'Smartphone Shop'}
            </h5>
            <p>{store?.description || 'Nơi cung cấp điện thoại uy tín, chất lượng và giá tốt nhất thị trường.'}</p>
            <p><i className="bi bi-geo-alt-fill me-2"></i>{store?.address || '123 Đường Số 1, Quận 1, TP.HCM'}</p>
            <p><i className="bi bi-telephone-fill me-2"></i>{store?.phoneNumber || '0909 999 999'}</p>
            <p><i className="bi bi-envelope-fill me-2"></i>{store?.email || 'support@smartphoneshop.vn'}</p>
          </div>

          {/* Cột 2: Chính sách & hỗ trợ */}
          <div className="col-md-4 mb-3">
            <h6 className="fw-bold text-uppercase">Chính sách</h6>
            <ul className="list-unstyled">
              <li><i className="bi bi-chevron-right me-2"></i>Chính sách bảo hành</li>
              <li><i className="bi bi-chevron-right me-2"></i>Chính sách đổi trả</li>
              <li><i className="bi bi-chevron-right me-2"></i>Chính sách giao hàng</li>
              <li><i className="bi bi-chevron-right me-2"></i>Điều khoản sử dụng</li>
            </ul>
          </div>

          {/* Cột 3: Mạng xã hội & thanh toán */}
          <div className="col-md-4 mb-3">
            <h6 className="fw-bold text-uppercase">Kết nối với chúng tôi</h6>
            <div className="mb-2">
              <a href="#" className="text-light me-3"><i className="bi bi-facebook fs-4"></i></a>
              <a href="#" className="text-light me-3"><i className="bi bi-instagram fs-4"></i></a>
              <a href="#" className="text-light me-3"><i className="bi bi-youtube fs-4"></i></a>
              <a href="#" className="text-light"><i className="bi bi-twitter-x fs-4"></i></a>
            </div>
            <h6 className="fw-bold mt-3">Thanh toán</h6>
            <div className="d-flex gap-2 flex-wrap">
              <img src="https://img.icons8.com/color/48/000000/visa.png" alt="Visa" height="32" />
              <img src="https://img.icons8.com/color/48/000000/mastercard-logo.png" alt="MasterCard" height="32" />
              <img src="https://img.icons8.com/color/48/000000/momo.png" alt="Momo" height="32" />
              <img src="https://img.icons8.com/color/48/000000/cash.png" alt="Cash" height="32" />
            </div>
          </div>
        </div>

        <hr className="border-light" />

        <div className="text-center">
          <small>© {new Date().getFullYear()} Smartphone Shop. All rights reserved.</small>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
