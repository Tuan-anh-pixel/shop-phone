import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Login from "../pages/Login";
import Register from "../pages/Register";
import ProductList from "../pages/ProductList";
import ProductDetail from "../pages/ProductDetail";
import Checkout from "../pages/Checkout";
import ThankYou from "../pages/ThankYou";
import CategoryPage from "../pages/CategoryPage";
import MyOrders from "../pages/MyOrders";
import ManageProducts from "../pages/admin/ManageProducts";
import ProductForm from "../pages/admin/ProductForm";
import AdminDashboard from "../pages/admin/AdminDashboard";
import ManageCategories from "../pages/admin/ManageCategories";
import ManageOrders from "../pages/admin/ManageOrders";
import ManageUsers from "../pages/admin/ManageUsers";
import StoreInfo from "../pages/admin/StoreInfo";
const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "",
        element: <ProductList />,
      },
      {
        path: "login",
        element: <Login />,
      },
      {
        path: "register",
        element: <Register />,
      },
      {
        path: "product/:id",
        element: <ProductDetail />,
      },
      {
        path: "checkout/:id",
        element: <Checkout />,
      },
      {
        path: "thank-you",
        element: <ThankYou />,
      },
      {
        path: "category/:id",
        element: <CategoryPage />,
      },
      {
        path: "my-orders",
        element: <MyOrders />,
      },
      //Admin
      { path: '', element: <AdminDashboard /> },
      { path: 'products', element: <ManageProducts /> },
      { path: 'admin/products/add', element: <ProductForm /> },
      { path: 'admin/products/edit/:id', element: <ProductForm /> },
      { path: 'categories', element: <ManageCategories /> },
      { path: 'orders', element: <ManageOrders /> },
      { path: 'users', element: <ManageUsers /> },
      { path: 'store', element: <StoreInfo /> }
    ],
  },
]);

export default router;
