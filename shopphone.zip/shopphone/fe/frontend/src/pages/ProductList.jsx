import { useEffect, useState } from "react";
import axios from "../api/axios";
import { Card, Row, Col, Spinner, Alert, Form } from "react-bootstrap";
import { Link } from "react-router-dom";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [resProducts, resCategories, resStore] = await Promise.all([
          axios.get("/products"),
          axios.get("/categories"),
          axios.get("/store"),
        ]);

        setAllProducts(resProducts.data.products);
        setProducts(resProducts.data.products);
        setCategories(resCategories.data.categories);
        setStore(resStore.data.store);
      } catch (err) {
        setMsg("Không thể tải dữ liệu");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleCategoryChange = (e) => {
    const catId = e.target.value;
    setSelectedCategory(catId);

    if (catId === "all") {
      setProducts(allProducts);
    } else {
      const filtered = allProducts.filter((p) => p.category?._id === catId);
      setProducts(filtered);
    }
  };

  return (
    <div className="container">
      {/* Banner */}
      <div className="p-4 mb-4 rounded bg-primary text-white text-center">
        <h1 className="display-5 fw-bold">Chào mừng đến với Smartphone Shop</h1>
        <p className="lead">
          Khám phá những mẫu điện thoại mới nhất và ưu đãi cực hot!
        </p>
      </div>

      {/* Store Info */}
      {store && (
        <div className="text-center mb-4">
          <h4 className="fw-bold text-primary">{store.name}</h4>
          <p>{store.description}</p>
        </div>
      )}

      {/* Bộ lọc danh mục */}
      <div className="mb-4 d-flex align-items-center justify-content-between flex-wrap gap-3">
        <h5 className="mb-0 fw-bold">📂 Danh mục sản phẩm:</h5>
        <Form.Select
          style={{ maxWidth: "300px" }}
          value={selectedCategory}
          onChange={handleCategoryChange}
        >
          <option value="all">Tất cả</option>
          {categories.map((cat) => (
            <option key={cat._id} value={cat._id}>
              {cat.name}
            </option>
          ))}
        </Form.Select>
      </div>

      {/* Danh sách sản phẩm */}
      {loading ? (
        <div className="text-center mt-5">
          <Spinner animation="border" variant="primary" />
        </div>
      ) : msg ? (
        <Alert variant="danger">{msg}</Alert>
      ) : (
        <Row>
          {categories.length > 0 && (
            <div className="mb-4">
              <div className="d-flex flex-wrap gap-2">
                <Link to="/" className="btn btn-outline-secondary btn-sm">
                  Tất cả
                </Link>
                {categories.map((cat) => (
                  <Link
                    key={cat._id}
                    to={`/category/${cat._id}`}
                    className="btn btn-outline-primary btn-sm"
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            </div>
          )}

          {products.map((product) => (
            <Col key={product._id} md={4} sm={6} xs={12} className="mb-4">
              <Card className="h-100 shadow-sm">
                <Card.Img
                  variant="top"
                  src={product.imageUrl}
                  style={{ height: "200px", objectFit: "cover" }}
                />
                <Card.Body className="d-flex flex-column">
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text className="mb-2">
                    <strong>Giá:</strong> ${product.price.toLocaleString()}
                    <br />
                    <strong>Danh mục:</strong> {product.category?.name}
                  </Card.Text>
                  <Link
                    to={`/product/${product._id}`}
                    className="btn btn-outline-primary mt-auto"
                  >
                    Xem chi tiết
                  </Link>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </div>
  );
};

export default ProductList;
