import { useEffect, useState } from 'react';
import axios from '../api/axios';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Form,
  Button,
  Row,
  Col,
  Alert,
  Spinner,
  Card,
} from 'react-bootstrap';

const Checkout = () => {
  const { id } = useParams(); // productId
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [form, setForm] = useState({
    customerName: '',
    phoneNumber: '',
    address: '',
    quantity: 1,
  });
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  useEffect(() => {
    axios
      .get(`/products/${id}`)
      .then((res) => setProduct(res.data.product))
      .catch(() => setMsg('Không thể tải thông tin sản phẩm.'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { customerName, phoneNumber, address, quantity } = form;
    if (!customerName || !phoneNumber || !address) {
      setMsg('Vui lòng nhập đầy đủ thông tin.');
      return;
    }

    try {
      await axios.post('/contacts', {
        ...form,
        product: product._id,
      });
      setSuccessMsg('🎉 Đặt hàng thành công! Chúng tôi sẽ liên hệ với bạn.');
      setForm({ customerName: '', phoneNumber: '', address: '', quantity: 1 });
    } catch (err) {
      setMsg('Có lỗi xảy ra khi đặt hàng.');
    }
  };

  if (loading)
    return (
      <div className="text-center mt-5">
        <Spinner animation="border" />
      </div>
    );
  if (!product) return <Alert variant="danger">{msg}</Alert>;

  return (
    <Row className="mt-4">
      <Col md={7}>
        <h3 className="fw-bold mb-3">📝 Thông tin đặt hàng</h3>
        {msg && <Alert variant="danger">{msg}</Alert>}
        {successMsg && <Alert variant="success">{successMsg}</Alert>}

        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Họ và tên</Form.Label>
            <Form.Control
              type="text"
              name="customerName"
              value={form.customerName}
              onChange={handleChange}
              placeholder="Nguyễn Văn A"
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Số điện thoại</Form.Label>
            <Form.Control
              type="text"
              name="phoneNumber"
              value={form.phoneNumber}
              onChange={handleChange}
              placeholder="0909999999"
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Địa chỉ giao hàng</Form.Label>
            <Form.Control
              as="textarea"
              name="address"
              value={form.address}
              onChange={handleChange}
              rows={2}
              placeholder="123 Lê Lợi, Quận 1, TP.HCM"
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Số lượng</Form.Label>
            <Form.Control
              type="number"
              name="quantity"
              min={1}
              value={form.quantity}
              onChange={handleChange}
            />
          </Form.Group>

          <Button variant="primary" size="lg" type="submit">
            ✅ Xác nhận đặt hàng
          </Button>
        </Form>
      </Col>

      <Col md={5}>
        <h4 className="fw-bold mb-3">📦 Sản phẩm</h4>
        <Card className="p-3 shadow-sm">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="img-fluid rounded mb-3"
            style={{ maxHeight: '250px', objectFit: 'contain' }}
          />
          <h5>{product.name}</h5>
          <p>
            <strong>Giá:</strong> ${product.price.toLocaleString()}
          </p>
          <p>
            <strong>Màu sắc:</strong> {product.color}
          </p>
        </Card>
      </Col>
    </Row>
  );
};

export default Checkout;
