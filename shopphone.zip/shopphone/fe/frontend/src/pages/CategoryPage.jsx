import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from '../api/axios';
import { Card, Row, Col, Spinner, Alert, Button } from 'react-bootstrap';

const CategoryPage = () => {
  const { id } = useParams(); // categoryId
  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategoryData = async () => {
      try {
        const [resCategory, resProducts] = await Promise.all([
          axios.get(`/categories/${id}`),
          axios.get('/products'),
        ]);

        const filteredProducts = resProducts.data.products.filter(
          (p) => p.category?._id === id,
        );

        setCategory(resCategory.data.category);
        setProducts(filteredProducts);
      } catch (err) {
        setMsg('Không thể tải danh mục hoặc sản phẩm');
      } finally {
        setLoading(false);
      }
    };

    fetchCategoryData();
  }, [id]);

  if (loading) return <div className="text-center mt-5"><Spinner animation="border" /></div>;
  if (msg) return <Alert variant="danger">{msg}</Alert>;

  return (
    <div className="container min-vh-100">
      <div className="d-flex justify-content-between align-items-center mb-4 ">
        <h3 className="fw-bold text-primary">
          Danh mục: {category?.name}
        </h3>
        <Button variant="outline-secondary" as={Link} to="/">
          ← Quay về trang chủ
        </Button>
      </div>

      <p>{category?.description}</p>

      {products.length === 0 ? (
        <Alert variant="info">Không có sản phẩm nào trong danh mục này.</Alert>
      ) : (
        <Row>
          {products.map((product) => (
            <Col key={product._id} md={4} sm={6} xs={12} className="mb-4">
              <Card className="h-100 shadow-sm">
                <Card.Img
                  variant="top"
                  src={product.imageUrl}
                  style={{ height: '200px', objectFit: 'cover' }}
                />
                <Card.Body className="d-flex flex-column">
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text className="mb-2">
                    <strong>Giá:</strong> ${product.price.toLocaleString()}
                  </Card.Text>
                  <Link
                    to={`/product/${product._id}`}
                    className="btn btn-outline-primary mt-auto"
                  >
                    Xem chi tiết
                  </Link>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </div>
  );
};

export default CategoryPage;
