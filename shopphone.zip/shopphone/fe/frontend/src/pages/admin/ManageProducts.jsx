import { useEffect, useState } from 'react';
import axios from '../../api/axios';
import { Table, Button, Spinner, Alert, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const ManageProducts = () => {
  const [products, setProducts] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showConfirm, setShowConfirm] = useState(false);
  const [selectedId, setSelectedId] = useState(null);

  const fetchProducts = async () => {
    try {
      const res = await axios.get('/products');
      setProducts(res.data.products);
    } catch (err) {
      setMsg('Lỗi khi tải sản phẩm.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = async () => {
    try {
      await axios.delete(`/products/${selectedId}`);
      setShowConfirm(false);
      fetchProducts();
    } catch {
      alert('Xóa thất bại.');
    }
  };

  return (
    <div>
      <h3 className="fw-bold mb-3">📦 Quản lý sản phẩm</h3>
      <div className="text-end mb-3">
        <Link to="/admin/products/add" className="btn btn-success">
          ➕ Thêm sản phẩm
        </Link>
      </div>

      {loading ? (
        <Spinner animation="border" />
      ) : msg ? (
        <Alert variant="danger">{msg}</Alert>
      ) : (
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Ảnh</th>
              <th>Tên</th>
              <th>Giá</th>
              <th>Màu</th>
              <th>Danh mục</th>
              <th>Ngày SX</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p._id}>
                <td>
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    style={{ height: '60px', objectFit: 'cover' }}
                  />
                </td>
                <td>{p.name}</td>
                <td>${p.price.toLocaleString()}</td>
                <td>{p.color}</td>
                <td>{p.category?.name}</td>
                <td>{new Date(p.manufacturingDate).toLocaleDateString()}</td>
                <td>
                  <Link to={`/admin/products/edit/${p._id}`} className="btn btn-sm btn-warning me-2">
                    ✏️
                  </Link>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => {
                      setSelectedId(p._id);
                      setShowConfirm(true);
                    }}
                  >
                    🗑️
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {/* Modal xác nhận xóa */}
      <Modal show={showConfirm} onHide={() => setShowConfirm(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Xác nhận</Modal.Title>
        </Modal.Header>
        <Modal.Body>Bạn có chắc muốn xóa sản phẩm này?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirm(false)}>Huỷ</Button>
          <Button variant="danger" onClick={handleDelete}>Xóa</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ManageProducts;
