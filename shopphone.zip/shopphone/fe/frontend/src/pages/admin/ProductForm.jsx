import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from '../../api/axios';
import { Form, Button, Spinner, Alert, Row, Col } from 'react-bootstrap';
import { toast } from 'react-toastify';

const predefinedSpecsKeys = [
  'Màn hình',
  'Vi xử lý',
  'RAM',
  'Bộ nhớ trong',
  'Pin',
  'Camera',
  'Hệ điều hành'
];

const keyMapping = {
  'Màn hình': 'screenSize',
  'Vi xử lý': 'processor',
  'RAM': 'ram',
  'Bộ nhớ trong': 'storage',
  'Pin': 'battery',
  'Camera': 'camera',
  'Hệ điều hành': 'os'
};

const ProductForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [categories, setCategories] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    color: '',
    manufacturingDate: '',
    imageUrl: '',
    category: '',
  });
  const [specs, setSpecs] = useState(predefinedSpecsKeys.map(key => ({ key, value: '' })));

  useEffect(() => {
    const fetchCategories = axios.get('/categories');
    const fetchProduct = isEdit ? axios.get(`/products/${id}`) : Promise.resolve();

    Promise.all([fetchCategories, fetchProduct])
      .then(([catRes, prodRes]) => {
        setCategories(catRes.data.categories);
        if (isEdit) {
          const p = prodRes.data.product;
          const specMap = p.specifications || {};
          setSpecs(predefinedSpecsKeys.map(key => {
            const backendKey = keyMapping[key];
            return { key, value: specMap[backendKey] || '' };
          }));
          setForm({
            name: p.name,
            description: p.description,
            price: p.price,
            color: p.color,
            manufacturingDate: p.manufacturingDate.split('T')[0],
            imageUrl: p.imageUrl,
            category: p.category?._id || '',
          });
        }
      })
      .catch(() => setMsg('Lỗi tải dữ liệu'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const specifications = {};
      specs.forEach(s => {
        if (s.value) {
          specifications[keyMapping[s.key]] = s.value;
        }
      });

      const body = {
        ...form,
        price: Number(form.price),
        specifications
      };

      if (isEdit) {
        await axios.patch(`/products/${id}`, body);
        toast.success('Cập nhật sản phẩm thành công!');
      } else {
        await axios.post('/products', body);
        toast.success('Thêm sản phẩm thành công!');
      }

      navigate('/products');
    } catch (err) {
      setMsg('Dữ liệu không hợp lệ hoặc lỗi máy chủ.');
    }
  };

  if (loading) return <Spinner animation="border" />;

  return (
    <div className='container mt-5 mb-5'>
      <h3 className="fw-bold mb-3">{isEdit ? '✏️ Sửa sản phẩm' : '➕ Thêm sản phẩm'}</h3>
      {msg && <Alert variant="danger">{msg}</Alert>}

      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Tên</Form.Label>
              <Form.Control name="name" value={form.name} onChange={handleChange} required />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Mô tả</Form.Label>
              <Form.Control as="textarea" rows={3} name="description" value={form.description} onChange={handleChange} />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Giá</Form.Label>
              <Form.Control type="number" name="price" value={form.price} onChange={handleChange} required />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Màu sắc</Form.Label>
              <Form.Control name="color" value={form.color} onChange={handleChange} />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Ngày sản xuất</Form.Label>
              <Form.Control type="date" name="manufacturingDate" value={form.manufacturingDate} onChange={handleChange} />
            </Form.Group>
          </Col>

          <Col md={6}>
            <Form.Group className="mb-4">
              <Form.Label>Thông số kỹ thuật</Form.Label>
              {specs.map((item, idx) => (
                <Row key={idx} className="mb-2">
                  <Col>
                    <Form.Control plaintext readOnly value={item.key} />
                  </Col>
                  <Col>
                    <Form.Control
                      placeholder="Giá trị"
                      value={item.value}
                      onChange={(e) => {
                        const newSpecs = [...specs];
                        newSpecs[idx].value = e.target.value;
                        setSpecs(newSpecs);
                      }}
                    />
                  </Col>
                </Row>
              ))}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Ảnh (URL)</Form.Label>
              <Form.Control name="imageUrl" value={form.imageUrl} onChange={handleChange} />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>Danh mục</Form.Label>
              <Form.Select name="category" value={form.category} onChange={handleChange}>
                <option value="">-- Chọn danh mục --</option>
                {categories.map((cat) => (
                  <option key={cat._id} value={cat._id}>
                    {cat.name}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Button type="submit" variant="primary" className="w-100">
              {isEdit ? 'Cập nhật' : 'Thêm sản phẩm'}
            </Button>
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default ProductForm;