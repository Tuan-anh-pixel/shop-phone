const AdminDashboard = () => {
  return (
    <div>
      <h2 className="fw-bold mb-4">📊 Tổng quan hệ thống</h2>
      <p>Chào mừng bạn đến trang quản trị!</p>
      <ul>
        <li>📦 Quản lý sản phẩm</li>
        <li>🗂️ Quản lý danh mục</li>
        <li>🧾 Quản lý đơn hàng</li>
        <li>👤 Quản lý người dùng</li>
      </ul>
    </div>
  );
};

export default AdminDashboard;
