import { useEffect, useState } from 'react';
import axios from '../../api/axios';
import { Table, Button, Modal, Form, Alert, Spinner } from 'react-bootstrap';

const ManageCategories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState({ name: '', description: '' });

  const fetchCategories = async () => {
    try {
      const res = await axios.get('/categories');
      setCategories(res.data.categories);
    } catch (err) {
      setMsg('Không thể tải danh sách danh mục.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleSave = async () => {
    try {
      if (editItem) {
        await axios.patch(`/categories/${editItem._id}`, form);
      } else {
        await axios.post('/categories', form);
      }
      setShowModal(false);
      fetchCategories();
    } catch {
      alert('Lỗi khi lưu danh mục');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Bạn có chắc muốn xoá?')) return;
    try {
      await axios.delete(`/categories/${id}`);
      fetchCategories();
    } catch {
      alert('Xoá thất bại.');
    }
  };

  const openModal = (item = null) => {
    setEditItem(item);
    setForm(item ? { name: item.name, description: item.description } : { name: '', description: '' });
    setShowModal(true);
  };

  return (
    <div>
      <h3 className="fw-bold mb-3">📁 Quản lý danh mục</h3>

      <div className="text-end mb-3">
        <Button onClick={() => openModal()} variant="success">➕ Thêm danh mục</Button>
      </div>

      {msg && <Alert variant="danger">{msg}</Alert>}
      {loading ? (
        <Spinner animation="border" />
      ) : (
        <Table striped bordered hover>
          <thead className="table-dark">
            <tr>
              <th>#</th>
              <th>Tên</th>
              <th>Mô tả</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c, i) => (
              <tr key={c._id}>
                <td>{i + 1}</td>
                <td>{c.name}</td>
                <td>{c.description || '-'}</td>
                <td>
                  <Button variant="warning" size="sm" onClick={() => openModal(c)} className="me-2">✏️</Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(c._id)}>🗑️</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>{editItem ? '✏️ Sửa' : '➕ Thêm'} danh mục</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group>
              <Form.Label>Tên danh mục</Form.Label>
              <Form.Control
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mt-2">
              <Form.Label>Mô tả</Form.Label>
              <Form.Control
                as="textarea"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>Huỷ</Button>
          <Button variant="primary" onClick={handleSave}>
            {editItem ? 'Cập nhật' : 'Thêm'}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ManageCategories;
