import { useEffect, useState } from 'react';
import axios from '../../api/axios';
import { Table, Button, Spinner, Alert, Modal, Form } from 'react-bootstrap';

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', role: 'customer' });

  const fetchUsers = async () => {
    try {
      const res = await axios.get('/');
      setUsers(res.data.users);
    } catch (err) {
      setMsg('Không thể tải danh sách người dùng.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const openModal = (user) => {
    setSelectedUser(user);
    setForm({ name: user.name, email: user.email, role: user.role });
    setShowModal(true);
  };

  const handleSave = async () => {
    try {
      await axios.patch(`/update/${selectedUser._id}`, {
        name: form.name,
        email: form.email,
        role: form.role,
      });
      setShowModal(false);
      fetchUsers();
    } catch {
      alert('Cập nhật thất bại');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Bạn chắc chắn muốn xoá người dùng này?')) return;
    try {
      await axios.delete(`/delete/${id}`);
      fetchUsers();
    } catch {
      alert('Không thể xoá người dùng.');
    }
  };

  return (
    <div>
      <h3 className="fw-bold mb-4">👤 Quản lý người dùng</h3>
      {msg && <Alert variant="danger">{msg}</Alert>}
      {loading ? (
        <Spinner animation="border" />
      ) : (
        <Table striped bordered hover responsive>
          <thead className="table-dark">
            <tr>
              <th>#</th>
              <th>Tên</th>
              <th>Email</th>
              <th>Vai trò</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={u._id}>
                <td>{i + 1}</td>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>
                  <Button variant="warning" size="sm" onClick={() => openModal(u)} className="me-2">✏️</Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(u._id)}>🗑️</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>✏️ Chỉnh sửa người dùng</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group>
              <Form.Label>Họ tên</Form.Label>
              <Form.Control value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Form.Group>
            <Form.Group className="mt-2">
              <Form.Label>Email</Form.Label>
              <Form.Control value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Form.Group>
            <Form.Group className="mt-2">
              <Form.Label>Vai trò</Form.Label>
              <Form.Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                <option value="customer">Customer</option>
                <option value="admin">Admin</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>Huỷ</Button>
          <Button variant="primary" onClick={handleSave}>Lưu</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ManageUsers;
