import { useEffect, useState } from 'react';
import axios from '../../api/axios';
import { Table, Button, Spinner, Alert, Modal, Form } from 'react-bootstrap';
import { format } from 'date-fns';

const ManageOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [newStatus, setNewStatus] = useState('');

  const fetchOrders = async () => {
    try {
      const res = await axios.get('/contacts');
      setOrders(res.data.contacts);
    } catch (err) {
      setMsg('Không thể tải đơn hàng');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Bạn chắc chắn muốn xoá đơn hàng này?')) return;
    await axios.delete(`/contacts/${id}`);
    fetchOrders();
  };

  const handleUpdateStatus = async () => {
    try {
      await axios.patch(`/contacts/${selectedOrder._id}`, { status: newStatus });
      setShowModal(false);
      fetchOrders();
    } catch {
      alert('Không thể cập nhật trạng thái');
    }
  };

  const openModal = (order) => {
    setSelectedOrder(order);
    setNewStatus(order.status);
    setShowModal(true);
  };

  return (
    <div>
      <h3 className="fw-bold mb-4">📦 Quản lý đơn hàng</h3>
      {msg && <Alert variant="danger">{msg}</Alert>}
      {loading ? (
        <Spinner animation="border" />
      ) : (
        <Table striped bordered hover responsive>
          <thead className="table-dark">
            <tr>
              <th>#</th>
              <th>Khách hàng</th>
              <th>Điện thoại</th>
              <th>Địa chỉ</th>
              <th>Sản phẩm</th>
              <th>Số lượng</th>
              <th>Trạng thái</th>
              <th>Ngày đặt</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order, idx) => (
              <tr key={order._id}>
                <td>{idx + 1}</td>
                <td>{order.customerName}</td>
                <td>{order.phoneNumber}</td>
                <td>{order.address}</td>
                <td>{order.product?.name || '(Xoá)'}</td>
                <td>{order.quantity}</td>
                <td>{order.status}</td>
                <td>{format(new Date(order.createdAt), 'dd/MM/yyyy HH:mm')}</td>
                <td>
                  <Button
                    variant="warning"
                    size="sm"
                    onClick={() => openModal(order)}
                    className="me-2"
                  >
                    ✏️
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleDelete(order._id)}
                  >
                    🗑️
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {/* Modal cập nhật trạng thái */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>🛠️ Cập nhật trạng thái</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Select
            value={newStatus}
            onChange={(e) => setNewStatus(e.target.value)}
          >
            <option value="pending">Đang chờ</option>
            <option value="processing">Đang xử lý</option>
            <option value="shipped">Đã gửi</option>
            <option value="delivered">Đã giao</option>
            <option value="cancelled">Đã huỷ</option>
          </Form.Select>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Huỷ
          </Button>
          <Button variant="primary" onClick={handleUpdateStatus}>
            Cập nhật
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ManageOrders;
