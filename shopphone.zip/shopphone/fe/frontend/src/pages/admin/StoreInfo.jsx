import { useEffect, useState } from 'react';
import axios from '../../api/axios';
import { Form, Button, Alert, Spinner, Card } from 'react-bootstrap';
import { toast } from 'react-toastify';

const StoreInfo = () => {
  const [store, setStore] = useState({
    name: '',
    address: '',
    phoneNumber: '',
    email: '',
    description: '',
  });
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    axios.get('/store')
      .then((res) => {
        setStore(res.data.store || {});
      })
      .catch(() => setMsg('Không thể tải thông tin cửa hàng.'))
      .finally(() => setLoading(false));
  }, []);

  const handleChange = (e) => {
    setStore({ ...store, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.patch('/store', store);
      toast.success('Cập nhật thành công!');
    } catch {
      toast.error('Lỗi khi cập nhật thông tin cửa hàng!');
    }
  };

  if (loading) return <Spinner animation="border" />;

  return (
    <div>
      <h3 className="fw-bold mb-4">🏪 Thông tin cửa hàng</h3>
      {msg && <Alert variant="danger">{msg}</Alert>}

      <Card className="p-4 shadow-sm">
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Tên cửa hàng</Form.Label>
            <Form.Control name="name" value={store.name} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Địa chỉ</Form.Label>
            <Form.Control name="address" value={store.address} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Số điện thoại</Form.Label>
            <Form.Control name="phoneNumber" value={store.phoneNumber} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control type="email" name="email" value={store.email} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-4">
            <Form.Label>Mô tả</Form.Label>
            <Form.Control as="textarea" name="description" value={store.description} onChange={handleChange} rows={3} />
          </Form.Group>

          <Button type="submit" variant="primary">Lưu thay đổi</Button>
        </Form>
      </Card>
    </div>
  );
};

export default StoreInfo;
