import { useEffect, useState } from 'react';
import axios from '../api/axios';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, Spinner, Alert, Row, Col, Badge, Table } from 'react-bootstrap';
import { format } from 'date-fns';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get(`/products/${id}`)
      .then((res) => setProduct(res.data.product))
      .catch(() => setMsg('Không thể tải thông tin sản phẩm.'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="text-center mt-5"><Spinner animation="border" /></div>;
  if (msg) return <Alert variant="danger">{msg}</Alert>;
  if (!product) return null;

  const handleBuyNow = () => {
    navigate(`/checkout/${product._id}`);
  };

  return (
    <Card className="p-4 shadow-sm container mt-5 mb-5">
      <Row>
        {/* Hình ảnh sản phẩm */}
        <Col md={6} className="text-center">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="img-fluid rounded"
            style={{ maxHeight: '400px', objectFit: 'contain' }}
          />
        </Col>

        {/* Thông tin sản phẩm */}
        <Col md={6}>
          <h2 className="fw-bold">{product.name}</h2>
          <h4 className="text-danger mb-3">${product.price.toLocaleString()}</h4>
          <p><strong>Màu sắc:</strong> <Badge bg="secondary">{product.color}</Badge></p>
          <p><strong>Danh mục:</strong> {product.category?.name}</p>
          <p><strong>Ngày sản xuất:</strong> {format(new Date(product.manufacturingDate), 'dd/MM/yyyy')}</p>
          <p><strong>Mô tả:</strong> {product.description}</p>

          <Button variant="primary" size="lg" className="px-4 py-2 rounded-pill" onClick={handleBuyNow}>
            🛒 Mua ngay
          </Button>
        </Col>
      </Row>

      {/* Bảng thông số kỹ thuật */}
      {product.specifications && (
        <div className="mt-5">
          <h5 className="fw-bold mb-3">📋 Thông số kỹ thuật:</h5>
          <Table bordered responsive>
            <tbody>
              {Object.entries(product.specifications).map(([key, value]) => (
                <tr key={key}>
                  <td className="fw-semibold text-capitalize">{key}</td>
                  <td>{value}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
    </Card>
  );
};

export default ProductDetail;
