import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const ThankYou = () => {
  return (
    <div className="text-center mt-5">
      <h2>Cảm ơn bạn đã đặt hàng!</h2>
      <p>Chúng tôi sẽ liên hệ bạn trong thời gian sớm nhất.</p>
      <Button as={Link} to="/" variant="success">
        Quay về trang chủ
      </Button>
    </div>
  );
};

export default ThankYou;
