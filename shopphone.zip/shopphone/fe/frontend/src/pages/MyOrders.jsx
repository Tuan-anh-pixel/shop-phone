import { useEffect, useState } from 'react';
import axios from '../api/axios';
import { Table, Alert, Spinner } from 'react-bootstrap';
import { format } from 'date-fns';

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await axios.get('/my-orders'); // ✅ gọi API mới
        setOrders(res.data.contacts);
      } catch (err) {
        setMsg('Không thể tải đơn hàng của bạn.');
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading)
    return (
      <div className="text-center mt-5">
        <Spinner animation="border" />
      </div>
    );
  if (msg) return <Alert variant="danger">{msg}</Alert>;
  if (orders.length === 0)
    return <Alert variant="info">Bạn chưa có đơn hàng nào.</Alert>;

  return (
    <div>
      <h3 className="fw-bold mb-4">📦 Đơn hàng của tôi</h3>

      <Table striped bordered hover responsive>
        <thead className="table-dark">
          <tr>
            <th>#</th>
            <th>Sản phẩm</th>
            <th>Số lượng</th>
            <th>Trạng thái</th>
            <th>Ngày đặt</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order, idx) => (
            <tr key={order._id}>
              <td>{idx + 1}</td>
              <td>{order.product?.name || '(Không có)'}</td>
              <td>{order.quantity}</td>
              <td>{order.status}</td>
              <td>{format(new Date(order.createdAt), 'dd/MM/yyyy HH:mm')}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default MyOrders;
