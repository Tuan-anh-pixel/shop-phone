import { Outlet } from 'react-router-dom';
import AppNavbar from './components/Navbar';
import Footer from './components/Footer';
import { Container } from 'react-bootstrap';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Toast from './components/Toast';

const App = () => {
  return (
    <>
      <AppNavbar />
      <div className="app-content">
        <Outlet />
      </div>
      <Footer />
      <Toast />
    </>
  );
};

export default App;
