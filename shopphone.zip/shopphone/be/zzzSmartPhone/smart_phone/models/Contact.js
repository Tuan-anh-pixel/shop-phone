const mongoose = require("mongoose");

const ContactSchema = new mongoose.Schema(
	{
		customerName: {
			type: String,
			required: [true, "Please provide customer name"],
			trim: true,
		},
		phoneNumber: {
			type: String,
			required: [true, "Please provide phone number"],
		},
		address: {
			type: String,
			required: [true, "Please provide shipping address"],
		},
		product: {
			type: mongoose.Schema.ObjectId,
			ref: "Product",
			required: [true, "Please provide product"],
		},
		quantity: {
			type: Number,
			required: [true, "Please provide quantity"],
			default: 1,
		},
		status: {
			type: String,
			enum: ["pending", "processing", "shipped", "delivered", "cancelled"],
			default: "pending",
		},
		paymentMethod: {
			type: String,
			enum: ["COD"],
			default: "COD",
		},
	},
	{ timestamps: true },
);

module.exports = mongoose.model("Contact", ContactSchema);
