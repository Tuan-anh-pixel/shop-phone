const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema(
	{
		name: {
			type: String,
			required: [true, "Please provide product name"],
			trim: true,
			maxlength: [100, "Name cannot be more than 100 characters"],
		},
		description: {
			type: String,
			required: [true, "Please provide product description"],
			maxlength: [1000, "Description cannot be more than 1000 characters"],
		},
		price: {
			type: Number,
			required: [true, "Please provide product price"],
			default: 0,
		},
		color: {
			type: String,
			required: [true, "Please provide product color"],
		},
		specifications: {
			type: Object,
			required: [true, "Please provide product specifications"],
		},
		manufacturingDate: {
			type: Date,
			required: [true, "Please provide manufacturing date"],
		},
		imageUrl: {
			type: String,
			required: [true, "Please provide product image URL"],
		},
		category: {
			type: mongoose.Schema.ObjectId,
			ref: "Category",
			required: [true, "Please provide product category"],
		},
	},
	{ timestamps: true },
);

module.exports = mongoose.model("Product", ProductSchema);
