const mongoose = require("mongoose");

const StoreSchema = new mongoose.Schema(
	{
		name: {
			type: String,
			required: [true, "Please provide store name"],
			trim: true,
			maxlength: [100, "Name cannot be more than 100 characters"],
		},
		address: {
			type: String,
			required: [true, "Please provide store address"],
			maxlength: [200, "Address cannot be more than 200 characters"],
		},
		phoneNumber: {
			type: String,
			required: [true, "Please provide store phone number"],
		},
		email: {
			type: String,
			required: [true, "Please provide store email"],
		},
		description: {
			type: String,
			maxlength: [500, "Description cannot be more than 500 characters"],
		},
	},
	{ timestamps: true },
);

module.exports = mongoose.model("Store", StoreSchema);
