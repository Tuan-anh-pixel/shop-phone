const express = require("express");
const router = express.Router();

const {
	login,
	register,
	getAllUsers,
	getSingleUser,
	updateUser,
	deleteUser,
} = require("../controllers/user");
const {
	getAllCategories,
	getSingleCategory,
	createCategory,
	updateCategory,
	deleteCategory,
} = require("../controllers/category");
const {
	getAllProducts,
	getSingleProduct,
	createProduct,
	updateProduct,
	deleteProduct,
} = require("../controllers/product");
const { getStoreInfo, updateStoreInfo } = require("../controllers/store");
const {
	getAllContacts,
	getSingleContact,
	createContact,
	updateContactStatus,
	deleteContact,
} = require("../controllers/contact");

const authMiddleware = require("../middleware/auth");

// Admin role check middleware
const adminMiddleware = (req, res, next) => {
	console.log(req.user);
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Access denied. Admin privileges required." });
	}
	next();
};

// ================ PUBLIC ROUTES ================

// Authentication routes
router.post("/login", login);
router.post("/register", register);

// Public product routes
router.get("/products", getAllProducts);
router.get("/products/:id", getSingleProduct);

// Public category routes
router.get("/categories", getAllCategories);
router.get("/categories/:id", getSingleCategory);

// Public store routes
router.get("/store", getStoreInfo);

// Public contact creation route
router.post("/contacts", createContact);
router.get("/contacts/:id", authMiddleware, getSingleContact);
router.patch("/update/:id", authMiddleware, updateUser);

// ================ AUTHENTICATED ROUTES ================

// ================ ADMIN ONLY ROUTES ================

// User management routes - ADMIN ONLY
router.get("/", authMiddleware, adminMiddleware, getAllUsers);
router.get("/detail/:id", authMiddleware, getSingleUser);
router.delete("/delete/:id", authMiddleware, adminMiddleware, deleteUser);

// Category management - ADMIN ONLY
router.post("/categories", authMiddleware, adminMiddleware, createCategory);
router.patch(
	"/categories/:id",
	authMiddleware,
	adminMiddleware,
	updateCategory,
);
router.delete(
	"/categories/:id",
	authMiddleware,
	adminMiddleware,
	deleteCategory,
);

// Product management - ADMIN ONLY
router.post("/products", authMiddleware, adminMiddleware, createProduct);
router.patch("/products/:id", authMiddleware, adminMiddleware, updateProduct);
router.delete("/products/:id", authMiddleware, adminMiddleware, deleteProduct);

// Store management - ADMIN ONLY
router.patch("/store", authMiddleware, adminMiddleware, updateStoreInfo);

// Contact management - ADMIN ONLY
router.get("/contacts", authMiddleware, adminMiddleware, getAllContacts);
router.patch(
	"/contacts/:id",
	authMiddleware,
	adminMiddleware,
	updateContactStatus,
);
router.delete("/contacts/:id", authMiddleware, adminMiddleware, deleteContact);

module.exports = router;
