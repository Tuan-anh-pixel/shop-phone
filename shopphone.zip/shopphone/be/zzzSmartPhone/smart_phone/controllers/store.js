const Store = require("../models/Store");

const getStoreInfo = async (req, res) => {
	const stores = await Store.find({});
	// Usually there will be only one store record
	const store = stores[0] || {};
	return res.status(200).json({ store });
};

const updateStoreInfo = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const { name, address, phoneNumber, email, description } = req.body;

	if (!name && !address && !phoneNumber && !email && !description) {
		return res.status(400).json({ msg: "Please provide values to update" });
	}

	// Find if store info exists already
	let store = await Store.findOne({});

	if (!store) {
		// Create new store info if it doesn't exist
		store = await Store.create({
			name: name || "Smartphone Store",
			address: address || "",
			phoneNumber: phoneNumber || "",
			email: email || "",
			description: description || "",
		});
	} else {
		// Update existing store info
		if (name) store.name = name;
		if (address) store.address = address;
		if (phoneNumber) store.phoneNumber = phoneNumber;
		if (email) store.email = email;
		if (description) store.description = description;

		await store.save();
	}

	return res.status(200).json({ store });
};

module.exports = {
	getStoreInfo,
	updateStoreInfo,
};
