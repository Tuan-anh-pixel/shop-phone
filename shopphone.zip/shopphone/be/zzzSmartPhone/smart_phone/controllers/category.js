const Category = require("../models/Category");

const getAllCategories = async (req, res) => {
	const categories = await Category.find({});
	return res.status(200).json({ categories, count: categories.length });
};

const getSingleCategory = async (req, res) => {
	const category = await Category.findById(req.params.id);
	if (!category) {
		return res
			.status(404)
			.json({ msg: `No category found with id ${req.params.id}` });
	}
	return res.status(200).json({ category });
};

const createCategory = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const { name, description } = req.body;

	if (!name) {
		return res.status(400).json({ msg: "Please provide category name" });
	}

	const category = await Category.create({ name, description });
	return res.status(201).json({ category });
};

const updateCategory = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const { name, description } = req.body;

	if (!name && !description) {
		return res.status(400).json({ msg: "Please provide values to update" });
	}

	const category = await Category.findById(req.params.id);
	if (!category) {
		return res
			.status(404)
			.json({ msg: `No category found with id ${req.params.id}` });
	}

	if (name) category.name = name;
	if (description) category.description = description;

	await category.save();

	return res.status(200).json({ category });
};

const deleteCategory = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const category = await Category.findById(req.params.id);
	if (!category) {
		return res
			.status(404)
			.json({ msg: `No category found with id ${req.params.id}` });
	}

	await Category.deleteOne({ _id: req.params.id });

	return res.status(200).json({ msg: "Category deleted successfully" });
};

module.exports = {
	getAllCategories,
	getSingleCategory,
	createCategory,
	updateCategory,
	deleteCategory,
};
