const Contact = require("../models/Contact");

const getAllContacts = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const contacts = await Contact.find({}).populate("product", "name price");
	return res.status(200).json({ contacts, count: contacts.length });
};

const getSingleContact = async (req, res) => {
	const contact = await Contact.findById(req.params.id).populate(
		"product",
		"name price imageUrl",
	);
	if (!contact) {
		return res
			.status(404)
			.json({ msg: `No contact found with id ${req.params.id}` });
	}
	return res.status(200).json({ contact });
};

const createContact = async (req, res) => {
	const { customerName, phoneNumber, address, product, quantity } = req.body;

	if (!customerName || !phoneNumber || !address || !product) {
		return res.status(400).json({ msg: "Please provide all contact details" });
	}

	const contact = await Contact.create({
		customerName,
		phoneNumber,
		address,
		product,
		quantity: quantity || 1,
	});

	return res.status(201).json({
		contact,
		msg: "Thank you for your order! We will contact you shortly.",
	});
};

const updateContactStatus = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const { status } = req.body;

	if (!status) {
		return res.status(400).json({ msg: "Please provide status to update" });
	}

	const contact = await Contact.findById(req.params.id);
	if (!contact) {
		return res
			.status(404)
			.json({ msg: `No contact found with id ${req.params.id}` });
	}

	contact.status = status;
	await contact.save();

	return res.status(200).json({ contact });
};

const deleteContact = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const contact = await Contact.findById(req.params.id);
	if (!contact) {
		return res
			.status(404)
			.json({ msg: `No contact found with id ${req.params.id}` });
	}

	await Contact.deleteOne({ _id: req.params.id });

	return res.status(200).json({ msg: "Contact deleted successfully" });
};

module.exports = {
	getAllContacts,
	getSingleContact,
	createContact,
	updateContactStatus,
	deleteContact,
};
