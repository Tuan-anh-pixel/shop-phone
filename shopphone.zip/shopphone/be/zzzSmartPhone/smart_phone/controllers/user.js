const jwt = require("jsonwebtoken");
const User = require("../models/User");
const bcrypt = require("bcryptjs");

const login = async (req, res) => {
	const { email, password } = req.body;

	if (!email || !password) {
		return res.status(400).json({
			msg: "Bad request. Please add email and password in the request body",
		});
	}

	let foundUser = await User.findOne({ email: req.body.email });

	if (foundUser) {
		const isMatch = await foundUser.comparePassword(password);

		if (isMatch) {
			const userWithoutPassword = foundUser.toObject();
			delete userWithoutPassword.password;
			const token = jwt.sign(
				{
					id: foundUser._id,
					name: foundUser.name,
					email: foundUser.email,
					role: foundUser.role,
				},
				process.env.JWT_SECRET,
				{
					expiresIn: "30d",
				},
			);

			return res
				.status(200)
				.json({ user: userWithoutPassword, msg: "user logged in", token });
		} else {
			return res.status(400).json({ msg: "Bad password" });
		}
	} else {
		return res.status(400).json({ msg: "Bad credentails" });
	}
};

const register = async (req, res) => {
	let foundUser = await User.findOne({ email: req.body.email });
	if (foundUser === null) {
		let { username, email, password } = req.body;
		if (username.length && email.length && password.length) {
			const person = new User({
				name: username,
				email: email,
				password: password,
			});
			await person.save();
			return res.status(201).json({ person });
		} else {
			return res
				.status(400)
				.json({ msg: "Please add all values in the request body" });
		}
	} else {
		return res.status(400).json({ msg: "Email already in use" });
	}
};

const getAllUsers = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const users = await User.find({}).select("-password");
	return res.status(200).json({ users, count: users.length });
};

const getSingleUser = async (req, res) => {
	// Check if user is admin or the requested user
	if (req.user.role !== "admin" && req.user.id !== req.params.id) {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const user = await User.findById(req.params.id).select("-password");
	if (!user) {
		return res
			.status(404)
			.json({ msg: `No user found with id ${req.params.id}` });
	}
	return res.status(200).json({ user });
};

const updateUser = async (req, res) => {
	const { name, email } = req.body;

	if (!name && !email) {
		return res.status(400).json({ msg: "Please provide values to update" });
	}

	const user = await User.findById(req.params.id);
	if (!user) {
		return res
			.status(404)
			.json({ msg: `No user found with id ${req.params.id}` });
	}

	if (name) user.name = name;
	if (email) user.email = email;

	await user.save();

	return res.status(200).json({
		user: {
			id: user._id,
			name: user.name,
			email: user.email,
			role: user.role,
		},
	});
};

const deleteUser = async (req, res) => {
	// Only admin can delete users
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const user = await User.findById(req.params.id);
	if (!user) {
		return res
			.status(404)
			.json({ msg: `No user found with id ${req.params.id}` });
	}

	await User.deleteOne({ _id: req.params.id });

	return res.status(200).json({ msg: "User deleted successfully" });
};

module.exports = {
	login,
	register,
	getAllUsers,
	getSingleUser,
	updateUser,
	deleteUser,
};
