const Product = require("../models/Product");

const getAllProducts = async (req, res) => {
	const products = await Product.find({}).populate("category", "name");
	return res.status(200).json({ products, count: products.length });
};

const getSingleProduct = async (req, res) => {
	const product = await Product.findById(req.params.id).populate(
		"category",
		"name",
	);
	if (!product) {
		return res
			.status(404)
			.json({ msg: `No product found with id ${req.params.id}` });
	}
	return res.status(200).json({ product });
};

const createProduct = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const {
		name,
		description,
		price,
		color,
		specifications,
		manufacturingDate,
		imageUrl,
		category,
	} = req.body;

	if (
		!name ||
		!description ||
		!price ||
		!color ||
		!specifications ||
		!manufacturingDate ||
		!imageUrl ||
		!category
	) {
		return res.status(400).json({ msg: "Please provide all product details" });
	}

	const product = await Product.create({
		name,
		description,
		price,
		color,
		specifications,
		manufacturingDate,
		imageUrl,
		category,
	});

	return res.status(201).json({ product });
};

const updateProduct = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const product = await Product.findById(req.params.id);
	if (!product) {
		return res
			.status(404)
			.json({ msg: `No product found with id ${req.params.id}` });
	}

	const fields = [
		"name",
		"description",
		"price",
		"color",
		"specifications",
		"manufacturingDate",
		"imageUrl",
		"category",
	];

	fields.forEach((field) => {
		if (req.body[field] !== undefined) {
			product[field] = req.body[field];
		}
	});

	await product.save();

	return res.status(200).json({ product });
};

const deleteProduct = async (req, res) => {
	// Check if user is admin
	if (req.user.role !== "admin") {
		return res
			.status(403)
			.json({ msg: "Unauthorized to access this resource" });
	}

	const product = await Product.findById(req.params.id);
	if (!product) {
		return res
			.status(404)
			.json({ msg: `No product found with id ${req.params.id}` });
	}

	await Product.deleteOne({ _id: req.params.id });

	return res.status(200).json({ msg: "Product deleted successfully" });
};

module.exports = {
	getAllProducts,
	getSingleProduct,
	createProduct,
	updateProduct,
	deleteProduct,
};
