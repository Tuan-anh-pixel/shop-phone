const fs = require("fs");
const path = require("path");

const seedDir = path.join(__dirname, "seed");
const seedFiles = fs
	.readdirSync(seedDir)
	.filter((file) => file.endsWith(".js"));

// Run each seed file in sequence
async function runSeeds() {
	for (const file of seedFiles) {
		console.log(`Running seed file: ${file}`);
		try {
			await require(path.join(seedDir, file));
		} catch (error) {
			console.error(`Error in ${file}:`, error);
		}
	}
}

runSeeds();
