const mongoose = require("mongoose");
const Category = require("../models/Category");
require("dotenv").config();

// Define smartphone categories
const phoneCategories = [
	{
		name: "Flagship Phones",
		description:
			"High-end smartphones with the latest technology and premium build quality. These are the best devices from each manufacturer.",
	},
	{
		name: "Mid-range Phones",
		description:
			"Balanced smartphones with good performance and features at a reasonable price point.",
	},
	{
		name: "Budget Phones",
		description:
			"Affordable smartphones that offer essential features at lower prices.",
	},
	{
		name: "Apple iPhones",
		description: "Apple's premium smartphone line running iOS.",
	},
	{
		name: "Samsung Galaxy",
		description: "Samsung's diverse range of Android smartphones.",
	},
	{
		name: "Xiaomi",
		description:
			"Xiaomi's smartphone lineup known for excellent value for money.",
	},
	{
		name: "OPPO",
		description:
			"OPPO's innovative smartphones with excellent camera capabilities.",
	},
	{
		name: "Vivo",
		description:
			"Vivo's range of stylish smartphones with advanced camera features.",
	},
	{
		name: "Realme",
		description:
			"Realme's performance-focused smartphones at competitive prices.",
	},
	{
		name: "OnePlus",
		description:
			"OnePlus smartphones offering flagship features at lower prices.",
	},
	{
		name: "Google Pixel",
		description:
			"Google's Pixel phones with exceptional camera quality and pure Android experience.",
	},
	{
		name: "Gaming Phones",
		description:
			"Specialized smartphones with enhanced performance and cooling for mobile gaming.",
	},
	{
		name: "Camera Phones",
		description:
			"Smartphones with exceptional photography and videography capabilities.",
	},
	{
		name: "Business Phones",
		description:
			"Smartphones with enhanced security and productivity features for professional use.",
	},
	{
		name: "Foldable Phones",
		description:
			"Innovative smartphones with folding displays that transform between phone and tablet form factors.",
	},
	{
		name: "5G Phones",
		description:
			"Smartphones with 5G connectivity for ultra-fast mobile data speeds.",
	},
	{
		name: "Large Screen Phones",
		description:
			"Smartphones with displays larger than 6.5 inches for enhanced media consumption.",
	},
	{
		name: "Compact Phones",
		description:
			"Smaller smartphones with screen sizes under 6 inches for easier one-handed use.",
	},
];

// Function to create categories
const createCategories = async () => {
	let connection;
	try {
		// Connect to MongoDB
		connection = await mongoose.connect(process.env.MONGO_URI);
		console.log("Connected to MongoDB");

		// Process each category individually to better handle existing categories
		let createdCount = 0;
		let existingCount = 0;

		for (const category of phoneCategories) {
			// Check if category already exists
			const existing = await Category.findOne({ name: category.name });

			if (existing) {
				console.log(`Category already exists: ${category.name}`);
				existingCount++;
			} else {
				// Create new category
				await Category.create(category);
				console.log(`Created category: ${category.name}`);
				createdCount++;
			}
		}

		console.log(`\nCategory creation complete:`);
		console.log(`- ${createdCount} new categories created`);
		console.log(`- ${existingCount} categories already existed`);

		// List all categories after operation
		const allCategories = await Category.find({});
		console.log(`\nTotal categories in database: ${allCategories.length}`);
		console.log("All categories:");
		allCategories.forEach((cat) => {
			console.log(`- ${cat.name}`);
		});
	} catch (error) {
		console.error("Error managing categories:", error);
	} finally {
		// Close the connection properly
		if (connection) {
			await mongoose.connection.close();
			console.log("Database connection closed");
		}
	}
};

// Execute the function
createCategories();
