const User = require("../models/User");
const mongoose = require("mongoose");
require("dotenv").config();

// Connect to MongoDB
mongoose
	.connect(process.env.MONGO_URI)
	.then(() => console.log("Connected to MongoDB"))
	.catch((err) => console.error("Could not connect to MongoDB", err));

// Admin user details
const adminUser = {
	name: "Admin User",
	email: "admin@example.com",
	password: "123456", // This will be hashed by the pre-save hook
	role: "admin",
};

// Function to create admin user if it doesn't exist
const createAdminUser = async () => {
	try {
		// Check if admin already exists
		const existingAdmin = await User.findOne({ email: adminUser.email });

		if (existingAdmin) {
			console.log(`Admin user with email ${adminUser.email} already exists`);
		} else {
			// Create new admin user - password will be hashed by the pre-save hook
			const user = await User.create(adminUser);
			console.log(
				`Admin user created successfully: ${user.name} (${user.email})`,
			);
		}

		// Count all admin users for information
		const adminCount = await User.countDocuments({ role: "admin" });
		console.log(`Total admin users in database: ${adminCount}`);
	} catch (error) {
		console.error("Error creating admin user:", error);
	} finally {
		// Close database connection
		mongoose.connection.close();
		console.log("Database connection closed");
	}
};

// Run the function
createAdminUser();
