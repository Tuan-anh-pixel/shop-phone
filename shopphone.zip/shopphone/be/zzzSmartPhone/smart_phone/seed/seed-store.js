const mongoose = require("mongoose");
const Store = require("../models/Store");
require("dotenv").config();

// Connect to MongoDB
mongoose
	.connect(process.env.MONGO_URI)
	.then(() => console.log("Connected to MongoDB"))
	.catch((err) => console.error("Could not connect to MongoDB", err));

// Default store data
const defaultStore = {
	name: "Smartphone Haven",
	address: "123 Tech Boulevard, Digital District, Hanoi, Vietnam",
	phoneNumber: "+84-123-456-789",
	email: "contact@smartphonehaven.com",
	description:
		"Vietnam's premier destination for the latest and greatest smartphones. We offer competitive prices, expert advice, and exceptional customer service. Visit us today to experience the future of mobile technology.",
};

// Function to seed store information
const seedStore = async () => {
	try {
		// Check if store data already exists
		const existingStore = await Store.findOne({});

		if (existingStore) {
			console.log("Store information already exists:");
			console.log(existingStore);
			console.log("No changes made.");
		} else {
			// Create new store
			const store = await Store.create(defaultStore);
			console.log("Store information created successfully:");
			console.log(store);
		}
	} catch (error) {
		console.error("Error seeding store information:", error);
	} finally {
		// Close the connection
		mongoose.connection.close();
		console.log("Database connection closed");
	}
};

// Run the seed function
seedStore();
